export default function handler(req, res) {
  if (req.method === 'POST') {
    const { email, orderNumber } = req.body;
    if (!email || !orderNumber) {
      return res.status(400).json({ error: 'Eksik bilgi gönderildi.' });
    }

    // Mock yanıt
    return res.status(200).json({
      status: 'Kargoya verildi',
      orderNumber,
      estimatedDelivery: '2-4 iş günü'
    });
  } else {
    res.status(405).json({ error: 'Yalnızca POST isteği desteklenir.' });
  }
}
